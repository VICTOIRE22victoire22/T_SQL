// Nettoyer le formulaire
let form = document.querySelector('form');
let btnEffacer = document.querySelector('#effacer');

btnEffacer.addEventListener('click', function () {
    form.reset();
});


// Afficher les informations de l'exposition


// Fetch ElevenLabs pour un Text-to-Speech